---
title: Troubleshooting
metadata:
    description: The chapter covers some common issues you may encounter with Select2, as well as where you can go to get help.
taxonomy:
    category: docs
---

# Troubleshooting

The chapter covers some common issues you may encounter with Select2, as well as where you can go to get help.